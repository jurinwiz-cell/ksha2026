<?php
if(!defined('__XE__')) exit();
class TablescannerController extends tablescanner
{
    function init() {}

    // ── 크론 URL 엔드포인트 (외부 스케줄러 전용) ──────────────────
    function procTablescannerCronRun()
    {
        $config   = getModel('module')->getModuleConfig('tablescanner');
        $cron_key = trim(Context::getRequestVars()->cron_key ?? '');

        if (empty($config->cron_key) || !hash_equals((string)$config->cron_key, $cron_key)) {
            header('HTTP/1.0 403 Forbidden');
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Invalid cron key']);
            exit;
        }

        $result = tablescanner::runBackup($config);

        if (!empty($result['success'])) {
            $config->backup_last_backup     = time();
            $es           = $result['email_sent'] ?? null;
            $email_status = ($es === true) ? 'sent' : (($es === false) ? 'failed' : (($es === 'size_exceeded') ? 'size_exceeded' : 'disabled'));
            $config->backup_last_email_status = $email_status;
            $config->backup_last_email_time   = time();
            $email_log = is_array($config->backup_email_log ?? null) ? $config->backup_email_log : (array)($config->backup_email_log ?? []);
            $email_log[basename($result['file'])] = $email_status;
            if (count($email_log ?? []) > 50) $email_log = array_slice($email_log, -50, 50, true);
            $config->backup_email_log = (object)$email_log;
            $type_log = is_array($config->backup_type_log ?? null) ? $config->backup_type_log : (array)($config->backup_type_log ?? []);
            $type_log[basename($result['file'])] = 'auto';
            if (count($type_log ?? []) > 50) $type_log = array_slice($type_log, -50, 50, true);
            $config->backup_type_log = (object)$type_log;
            getController('module')->insertModuleConfig('tablescanner', $config);
        }

        header('Content-Type: application/json');
        echo json_encode([
            'success' => !empty($result['success']),
            'file'    => !empty($result['file']) ? basename($result['file']) : null,
            'size_kb' => $result['size_kb'] ?? null,
            'method'  => $result['method']  ?? null,
            'email'   => $result['email_sent'] ?? null,
            'error'   => $result['error']   ?? null,
            'time'    => date('Y-m-d H:i:s'),
        ]);
        exit;
    }

    function triggerAutoCleanup($obj)
    {
        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config || empty($config->auto_cleanup_enabled) || $config->auto_cleanup_enabled !== 'Y') {
            return new BaseObject();
        }

        $interval_sec = max(1, (int)($config->auto_cleanup_interval ?? 7)) * 86400;
        $last_run     = (int)($config->auto_cleanup_last_run ?? 0);

        if (time() - $last_run < $interval_sec) return new BaseObject();

        $oDB     = DB::getInstance();
        $prefix  = $oDB->prefix;
        $targets = tablescanner::cleanupTargets();
        $days    = max(1, (int)($config->auto_cleanup_days ?? 90));
        $sel     = !empty($config->auto_cleanup_targets) ? (array)$config->auto_cleanup_targets : array_keys($targets);
        $thr     = date('YmdHis', strtotime("-{$days} days"));

        foreach ($sel as $bare) {
            if (!isset($targets[$bare])) continue;
            $full = $prefix . $bare;
            $col  = $targets[$bare]['date_col'];

            // ★ 소문자 from/table: addPrefixes가 $full을 이중 prefix하는 것을 방지
            $chk  = $oDB->query("select COUNT(*) as cnt from information_schema.tables where table_schema=DATABASE() and table_name=?", [$full]);
            $chkr = $chk ? $chk->fetchAll(PDO::FETCH_OBJ) : [];
            if (empty($chkr) || (int)$chkr[0]->cnt === 0) continue;

            $oDB->query("delete from `{$full}` where `{$col}` < ?", [$thr]);
            $oDB->query("optimize table `{$full}`", []);
        }

        $config->auto_cleanup_last_run = time();
        getController('module')->insertModuleConfig('tablescanner', $config);

        return new BaseObject();
    }

    function triggerAutoBackup($obj)
    {
        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config || empty($config->backup_auto_enabled) || $config->backup_auto_enabled !== 'Y') {
            return new BaseObject();
        }

        // Queue에 등록된 경우 트리거 방식 스킵 (중복 실행 방지)
        if (config('queue.enabled') && !empty($config->backup_queue_task_srl)) {
            return new BaseObject();
        }

        $last_run      = (int)($config->backup_last_backup ?? 0);
        $backup_hour   = (int)($config->backup_hour ?? 3);
        $today_sched   = mktime($backup_hour, 0, 0);  // 오늘 예약 시각 타임스탬프

        // 오늘 예약 시각이 아직 안 됐으면 스킵
        if (time() < $today_sched) return new BaseObject();
        // 오늘 예약 시각 이후 이미 백업했으면 스킵 (수동 백업도 포함)
        if ($last_run >= $today_sched) return new BaseObject();

        $result = tablescanner::runBackup($config);

        if (!empty($result['success'])) {
            $config->backup_last_backup = time();
            $es = $result['email_sent'] ?? null;
            $email_status = ($es === true) ? 'sent' : (($es === false) ? 'failed' : (($es === 'size_exceeded') ? 'size_exceeded' : 'disabled'));
            $config->backup_last_email_status = $email_status;
            $config->backup_last_email_time   = time();
            $email_log = is_array($config->backup_email_log ?? null) ? $config->backup_email_log : (array)($config->backup_email_log ?? []);
            $email_log[basename($result['file'])] = $email_status;
            if (count($email_log ?? []) > 50) $email_log = array_slice($email_log, -50, 50, true);
            $config->backup_email_log = (object)$email_log;
            $type_log = is_array($config->backup_type_log ?? null) ? $config->backup_type_log : (array)($config->backup_type_log ?? []);
            $type_log[basename($result['file'])] = 'auto';
            if (count($type_log ?? []) > 50) $type_log = array_slice($type_log, -50, 50, true);
            $config->backup_type_log = (object)$type_log;
            getController('module')->insertModuleConfig('tablescanner', $config);
        }

        return new BaseObject();
    }
}
