<?php
if(!defined('__XE__')) exit();
class TablescannerModel extends tablescanner
{
    function init() {}

    // ── Tab 1: 고아 테이블 스캐너 ──────────────────────────────
    function scanTables()
    {
        $oDB        = DB::getInstance();
        $prefix     = $oDB->prefix;           // Rhymix __get 매직 → $_prefix 반환
        $prefix_len = strlen($prefix);
        $module_path = RX_BASEDIR . 'modules/';

        // ★ 소문자 from: addPrefixes()가 information_schema를 xe_information_schema로
        //   오변환하는 것을 방지 (addPrefixes는 대문자 FROM/TABLE만 매칭)
        $stmt = $oDB->query("select table_name as table_name, table_rows as table_rows, ROUND((data_length+index_length)/1024,1) as size_kb from information_schema.tables where table_schema = DATABASE() order by table_name", []);
        $db_tables = [];
        if ($stmt) {
            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) {
                $name = $row->table_name;
                $bare = ($prefix_len && strpos($name, $prefix) === 0) ? substr($name, $prefix_len) : $name;
                $db_tables[$bare] = ['full_name' => $name, 'rows' => (int)$row->table_rows, 'size_kb' => (float)$row->size_kb];
            }
        }

        $schema_map = [];
        foreach (scandir($module_path) as $mod) {
            if ($mod === '.' || $mod === '..') continue;
            foreach (glob($module_path . $mod . '/schemas/*.xml') ?: [] as $xml_path) {
                $content = file_get_contents($xml_path);
                if (!preg_match_all('/<table\s([^>]*)>/i', $content, $tag_matches)) continue;
                foreach ($tag_matches[1] as $attrs) {
                    // deleted="true" 테이블 제외 (Rhymix 마이그레이션 삭제 마커)
                    if (preg_match('/\bdeleted\s*=\s*["\']true["\']/', $attrs)) continue;
                    if (preg_match('/\bname\s*=\s*["\']([^"\']+)["\']/', $attrs, $nm)) {
                        $schema_map[$nm[1]] = $mod;
                    }
                }
            }
        }

        $core_tables = [
            'action_forward','addons','addons_site','admin_favorite','admin_log',
            'autoinstall_packages','ai_installed_packages','ai_remote_categories',
            'comments','comments_list','comment_declared','comment_declared_log','comment_voted_log',
            'counter_log','counter_status',
            'documents','document_aliases','document_categories','document_declared',
            'document_declared_log','document_extra_keys','document_extra_vars',
            'document_histories','document_readed_log','document_trash',
            'document_update_log','document_voted_log','domains',
            'editor_autosave','editor_components','editor_components_site',
            'files','files_changelog','imageexif','lang','layouts',
            'member','member_agreed','member_auth_mail','member_auth_sms',
            'member_autologin','member_count_history','member_denied_nick_name',
            'member_denied_user_id','member_devices','member_friend','member_friend_group',
            'member_group','member_group_member','member_join_form','member_login_count',
            'member_managed_email_hosts','member_message','member_nickname_log',
            'member_scrap','member_scrap_folders',
            'menu','menu_item','menu_layout',
            'modules','module_admins','module_categories','module_config',
            'module_extend','module_extra_vars','module_filebox','module_grants',
            'module_locks','module_mobile_skins','module_part_config','module_skins',
            'module_trigger','module_update',
            'ncenterlite_notify','ncenterlite_notify_type','ncenterlite_unsubscribe','ncenterlite_user_set',
            'point','poll','poll_item','poll_log','poll_title',
            'pullup_logs','sequence','session','sites',
            'spamfilter_denied_ip','spamfilter_denied_word','spamfilter_log',
            'tags','trash','task_queue','task_schedule',
            'advanced_mailer_log','advanced_mailer_push_log','advanced_mailer_sms_log',
        ];

        // 애드온(addons/)이 만든 테이블은 schemas/*.xml 스캔으로는 절대 못 잡는다(애드온은 이
        // 스키마 메커니즘 자체를 안 씀). 그래서 실제로는 주인이 있는데도 "고아"로 오판되어 DROP
        // 버튼에 노출되는 것을 막기 위해, 알려진 애드온 소유 테이블을 별도로 예외 처리한다.
        // (예: lef_moved_files는 lua_external_file 애드온 소유 — bsplus_external_storage의
        // "구버전 애드온 이동 기록 가져오기" 기능이 아직 참조하므로 삭제 후보에 넣으면 안 됨.)
        $addon_tables = [
            'lef_moved_files' => 'lua_external_file (addon)',
        ];

        $matched = []; $real_orphaned = []; $core_matched = []; $addon_matched = []; $missing = [];

        foreach ($db_tables as $bare => $info) {
            if (isset($schema_map[$bare])) {
                $matched[$bare] = array_merge($info, ['module' => $schema_map[$bare]]);
            } elseif (in_array($bare, $core_tables ?? [])) {
                $core_matched[$bare] = array_merge($info, ['module' => 'XE Core']);
            } elseif (isset($addon_tables[$bare])) {
                $addon_matched[$bare] = array_merge($info, ['module' => $addon_tables[$bare]]);
            } else {
                $real_orphaned[$bare] = $info;
            }
        }

        foreach ($schema_map as $bare => $mod) {
            if (!isset($db_tables[$bare])) $missing[$bare] = ['module' => $mod];
        }

        ksort($matched); ksort($real_orphaned); ksort($core_matched); ksort($addon_matched); ksort($missing);
        return compact('matched', 'real_orphaned', 'core_matched', 'addon_matched', 'missing');
    }

    // ── Tab 2: DB 대시보드 ─────────────────────────────────────
    function getDashboardData()
    {
        $oDB = DB::getInstance();

        $stmt  = $oDB->query("select COUNT(*) as table_count, ROUND(SUM(data_length+index_length)/1024/1024,2) as total_mb, ROUND(SUM(data_free)/1024/1024,2) as total_free_mb, SUM(table_rows) as total_rows from information_schema.tables where table_schema=DATABASE()", []);
        $rows  = $stmt ? $stmt->fetchAll(PDO::FETCH_OBJ) : [];
        $total = $rows[0] ?? null;

        $stmt2      = $oDB->query("select table_name as table_name, table_rows as table_rows, engine as engine, ROUND((data_length+index_length)/1024/1024,2) as size_mb, ROUND(data_free/1024/1024,2) as free_mb from information_schema.tables where table_schema=DATABASE() order by (data_length+index_length) DESC limit 10", []);
        $top_tables = [];
        if ($stmt2) {
            foreach ($stmt2->fetchAll(PDO::FETCH_OBJ) as $row) $top_tables[] = (array)$row;
        }

        $stmt3       = $oDB->query("select table_name as table_name, ROUND((data_length+index_length)/1024/1024,2) as size_mb, ROUND(data_free/1024/1024,2) as free_mb, ROUND(data_free/(data_length+index_length+1)*100,1) as frag_pct from information_schema.tables where table_schema=DATABASE() and data_free>0 order by data_free DESC limit 5", []);
        $frag_tables = [];
        if ($stmt3) {
            foreach ($stmt3->fetchAll(PDO::FETCH_OBJ) as $row) $frag_tables[] = (array)$row;
        }

        return compact('total', 'top_tables', 'frag_tables');
    }

    // ── Tab 3: 테이블 최적화 ───────────────────────────────────
    function getOptimizeData()
    {
        $oDB  = DB::getInstance();
        $stmt = $oDB->query("select table_name as table_name, table_rows as table_rows, engine as engine, ROUND(data_length/1024/1024,2) as data_mb, ROUND(index_length/1024/1024,2) as index_mb, ROUND(data_free/1024/1024,2) as free_mb from information_schema.tables where table_schema = DATABASE() order by data_free DESC, data_length DESC", []);
        $tables = [];
        if ($stmt) {
            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) {
                $r = (array)$row;
                $r['table_rows_fmt'] = number_format((int)$r['table_rows']);
                $tables[] = $r;
            }
        }
        return $tables;
    }

    // ── Tab 4: 비대 로그 정리 ──────────────────────────────────
    function getCleanupData()
    {
        $oDB       = DB::getInstance();
        $prefix    = $oDB->prefix;
        $targets   = tablescanner::cleanupTargets();
        $threshold = date('YmdHis', strtotime('-90 days'));
        $result    = [];

        foreach ($targets as $bare => $meta) {
            $full = $prefix . $bare;
            $col  = $meta['date_col'];

            // ★ 소문자 from: addPrefixes 우회 ($full은 이미 prefix 포함)
            $chk  = $oDB->query("select COUNT(*) as cnt from information_schema.tables where table_schema=DATABASE() and table_name=?", [$full]);
            $chkr = $chk ? $chk->fetchAll(PDO::FETCH_OBJ) : [];
            if (empty($chkr) || (int)$chkr[0]->cnt === 0) continue;

            $cnt  = $oDB->query("select COUNT(*) as cnt from `{$full}`", []);
            $cntr = $cnt ? $cnt->fetchAll(PDO::FETCH_OBJ) : [];

            $size  = $oDB->query("select ROUND((data_length+index_length)/1024/1024,2) as size_mb from information_schema.tables where table_schema=DATABASE() and table_name=?", [$full]);
            $sizer = $size ? $size->fetchAll(PDO::FETCH_OBJ) : [];

            $old  = $oDB->query("select MIN(`{$col}`) as oldest, MAX(`{$col}`) as newest from `{$full}`", []);
            $oldr = $old ? $old->fetchAll(PDO::FETCH_OBJ) : [];

            $prev  = $oDB->query("select COUNT(*) as cnt from `{$full}` where `{$col}` < ?", [$threshold]);
            $prevr = $prev ? $prev->fetchAll(PDO::FETCH_OBJ) : [];

            $result[$bare] = [
                'label'      => $meta['label'],
                'date_col'   => $col,
                'count'      => !empty($cntr)  ? (int)$cntr[0]->cnt        : 0,
                'size_mb'    => !empty($sizer) ? (float)$sizer[0]->size_mb : 0,
                'oldest'     => !empty($oldr)  ? $oldr[0]->oldest          : '-',
                'newest'     => !empty($oldr)  ? $oldr[0]->newest          : '-',
                'preview_90' => !empty($prevr) ? (int)$prevr[0]->cnt       : 0,
            ];
        }
        return $result;
    }

    function getCleanupPreview($bare, $days)
    {
        $targets = tablescanner::cleanupTargets();
        if (!isset($targets[$bare])) return 0;

        $oDB       = DB::getInstance();
        $prefix    = $oDB->prefix;
        $full      = $prefix . $bare;
        $col       = $targets[$bare]['date_col'];
        $threshold = date('YmdHis', strtotime("-{$days} days"));

        $stmt = $oDB->query("select COUNT(*) as cnt from `{$full}` where `{$col}` < ?", [$threshold]);
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_OBJ) : [];
        return !empty($rows) ? (int)$rows[0]->cnt : 0;
    }

    // ── Tab 6: 백업 목록 ───────────────────────────────────────
    function getBackupList($config = null)
    {
        $dirs = [
            ['path' => tablescanner::getBackupDir($config), 'label' => '기본'],
        ];
        if (!empty($config->backup_path2)) {
            $dirs[] = ['path' => rtrim(str_replace('\\', '/', $config->backup_path2), '/') . '/', 'label' => '추가'];
        }

        $email_log = (array)($config->backup_email_log ?? []);
        $type_log  = (array)($config->backup_type_log  ?? []);
        $seen  = [];
        $files = [];
        foreach ($dirs as $dir_info) {
            $dir = $dir_info['path'];
            foreach (glob($dir . 'backup_*.sql*') ?: [] as $f) {
                $key = basename($f) . '|' . $dir_info['label'];
                if (isset($seen[$key])) continue;
                $seen[$key] = true;
                $size = filesize($f);
                $fname = basename($f);
                $files[] = [
                    'filename'     => $fname,
                    'filepath'     => $f,
                    'dir_label'    => $dir_info['label'],
                    'size_kb'      => round($size / 1024, 1),
                    'size_mb'      => round($size / 1024 / 1024, 2),
                    'mtime'        => filemtime($f),
                    'date'         => date('Y-m-d H:i:s', filemtime($f)),
                    'is_gz'        => substr($f, -3) === '.gz',
                    'email_status' => $email_log[$fname] ?? null,
                    'backup_type'  => $type_log[$fname]  ?? null,
                ];
            }
        }
        usort($files, function($a, $b) { return $b['mtime'] - $a['mtime']; });
        return $files;
    }

    // ── Tab 5: 테이블 점검 ─────────────────────────────────────
    function getCheckData()
    {
        $oDB  = DB::getInstance();
        $stmt = $oDB->query("select table_name as table_name from information_schema.tables where table_schema = DATABASE() order by table_name", []);
        $tables = [];
        if ($stmt) {
            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) $tables[] = $row->table_name;
        }
        return ['tables' => $tables, 'results' => []];
    }
}
