<?php
if(!defined('__XE__')) exit();
class TablescannerAdminController extends tablescanner
{
    function init() {}

    private function checkAdmin()
    {
        $logged_info = Context::get('logged_info');
        return ($logged_info && $logged_info->is_admin === 'Y');
    }

    // ── OPTIMIZE / ANALYZE ─────────────────────────────────────
    function procTablescannerAdminOptimize()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));
        @set_time_limit(0);

        $obj    = Context::getRequestVars();
        $action = $obj->optimize_action;
        $oDB    = DB::getInstance();

        // ★ 소문자 from: addPrefixes 우회
        $stmt = $oDB->query("select table_name as table_name from information_schema.tables where table_schema = DATABASE() order by table_name", []);
        $all_tables = [];
        if ($stmt) {
            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) $all_tables[] = $row->table_name;
        }

        if (empty($all_tables)) return $this->makeObject(-1, lang('msg_no_tables'));

        $cmd = strtoupper($action) === 'ANALYZE' ? 'ANALYZE' : 'OPTIMIZE';
        foreach ($all_tables as $tname) {
            // ★ 소문자 table: 전체 table명($tname)에 이미 prefix 있으므로 addPrefixes 우회
            $oDB->query("$cmd table `{$tname}`", []);
        }

        $this->setMessage(sprintf(lang('msg_optimize_done'), $cmd, count($all_tables ?? [])));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminOptimize'));
    }

    // ── CLEANUP ────────────────────────────────────────────────
    function procTablescannerAdminCleanup()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $obj     = Context::getRequestVars();
        $bare    = $obj->target_table;
        $days    = max(7, (int)$obj->days);
        $targets = tablescanner::cleanupTargets();

        if (!isset($targets[$bare])) {
            return $this->makeObject(-1, lang('msg_invalid_request'));
        }

        $oDB       = DB::getInstance();
        $prefix    = $oDB->prefix;
        $full      = $prefix . $bare;
        $col       = $targets[$bare]['date_col'];
        $threshold = date('YmdHis', strtotime("-{$days} days"));

        $cnt_stmt = $oDB->query("select COUNT(*) as cnt from `{$full}` where `{$col}` < ?", [$threshold]);
        $cnt_rows = $cnt_stmt ? $cnt_stmt->fetchAll(PDO::FETCH_OBJ) : [];
        $deleted  = !empty($cnt_rows) ? (int)$cnt_rows[0]->cnt : 0;

        $oDB->query("delete from `{$full}` where `{$col}` < ?", [$threshold]);
        $oDB->query("optimize table `{$full}`", []);

        $this->setMessage(sprintf(lang('msg_cleanup_done'), $deleted, $days));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminCleanup'));
    }

    // ── DROP 고아 테이블 ───────────────────────────────────────
    function procTablescannerAdminDropTable()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $obj  = Context::getRequestVars();
        $bare = trim($obj->table_bare);

        if (!$bare || !preg_match('/^[a-zA-Z0-9_]+$/', $bare)) {
            return $this->makeObject(-1, lang('msg_invalid_table_name'));
        }

        $oModel = getModel('tablescanner');
        $scan   = $oModel->scanTables();

        if (!isset($scan['real_orphaned'][$bare])) {
            return $this->makeObject(-1, lang('msg_not_orphaned_table'));
        }

        $oDB    = DB::getInstance();
        $prefix = $oDB->prefix;
        $full   = $prefix . $bare;

        $chk  = $oDB->query("select COUNT(*) as cnt from information_schema.tables where table_schema=DATABASE() and table_name=?", [$full]);
        $chkr = $chk ? $chk->fetchAll(PDO::FETCH_OBJ) : [];
        if (empty($chkr) || (int)$chkr[0]->cnt === 0) {
            return $this->makeObject(-1, lang('msg_table_not_exists'));
        }

        $oDB->query("drop table `{$full}`", []);

        $this->setMessage(sprintf(lang('msg_drop_done'), $full));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminScan'));
    }

    // ── 자동 정리 스케줄 저장 ─────────────────────────────────
    function procTablescannerAdminSaveSchedule()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config) $config = new stdClass();

        $config->auto_cleanup_enabled  = isset($_POST['auto_cleanup_enabled']) ? 'Y' : 'N';
        $config->auto_cleanup_days     = max(7, (int)($_POST['auto_cleanup_days'] ?? 90));
        $config->auto_cleanup_interval = max(1, (int)($_POST['auto_cleanup_interval'] ?? 7));
        $config->auto_cleanup_targets  = isset($_POST['auto_cleanup_targets']) && is_array($_POST['auto_cleanup_targets'])
            ? array_values(array_filter($_POST['auto_cleanup_targets']))
            : [];

        getController('module')->insertModuleConfig('tablescanner', $config);

        $this->setMessage(lang('msg_schedule_saved'));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminCleanup'));
    }

    // ── 백업 실행 ──────────────────────────────────────────────
    function procTablescannerAdminRunBackup()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $config = getModel('module')->getModuleConfig('tablescanner');
        $result = tablescanner::runBackup($config);

        if (!empty($result['success'])) {
            if ($config) {
                $config->backup_last_backup = time();
                $es = $result['email_sent'] ?? null;
                $email_status = ($es === true) ? 'sent' : (($es === false) ? 'failed' : (($es === 'size_exceeded') ? 'size_exceeded' : 'disabled'));
                $config->backup_last_email_status = $email_status;
                $config->backup_last_email_time   = time();
                // 파일별 이메일 결과 기록
                $email_log = is_array($config->backup_email_log ?? null) ? $config->backup_email_log : (array)($config->backup_email_log ?? []);
                $email_log[basename($result['file'])] = $email_status;
                if (count($email_log ?? []) > 50) $email_log = array_slice($email_log, -50, 50, true);
                $config->backup_email_log = (object)$email_log;
                // 파일별 백업 구분 (수동/예약) 기록
                $type_log = is_array($config->backup_type_log ?? null) ? $config->backup_type_log : (array)($config->backup_type_log ?? []);
                $type_log[basename($result['file'])] = 'manual';
                if (count($type_log ?? []) > 50) $type_log = array_slice($type_log, -50, 50, true);
                $config->backup_type_log = (object)$type_log;
                getController('module')->insertModuleConfig('tablescanner', $config);
            }
            $msg = sprintf(lang('msg_backup_done'), basename($result['file']), $result['size_kb'], $result['method']);
            switch ($result['email_sent'] ?? null) {
                case true:
                    $msg .= ' | ' . sprintf(lang('msg_email_sent'), $result['email_to']);
                    break;
                case false:
                    $msg .= ' | ' . lang('msg_email_failed');
                    break;
                case 'size_exceeded':
                    $msg .= ' | ' . lang('msg_email_size_exceeded');
                    break;
                // null: 이메일 미설정 → 추가 메시지 없음
            }
            $this->setMessage($msg);
        } else {
            $this->setMessage(lang('msg_backup_failed') . ': ' . ($result['error'] ?? ''));
        }
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminBackup'));
    }

    // ── 백업 파일 삭제 ──────────────────────────────────────────
    function procTablescannerAdminDeleteBackup()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $config   = getModel('module')->getModuleConfig('tablescanner');
        $filename = basename(Context::getRequestVars()->filename ?? '');

        if (!preg_match('/^backup_\d{8}_\d{6}\.sql(\.gz)?$/', $filename)) {
            return $this->makeObject(-1, lang('msg_invalid_request'));
        }

        $filepath = tablescanner::getBackupDir($config) . $filename;
        if (file_exists($filepath)) @unlink($filepath);

        // 이메일 로그 / 구분 로그에서도 제거
        if ($config) {
            $email_log = (array)($config->backup_email_log ?? []);
            unset($email_log[$filename]);
            $config->backup_email_log = (object)$email_log;
            $type_log = (array)($config->backup_type_log ?? []);
            unset($type_log[$filename]);
            $config->backup_type_log = (object)$type_log;
            getController('module')->insertModuleConfig('tablescanner', $config);
        }

        $this->setMessage(lang('msg_backup_deleted'));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminBackup'));
    }

    // ── 백업 파일 다운로드 ──────────────────────────────────────
    function procTablescannerAdminDownloadBackup()
    {
        if (!$this->checkAdmin()) {
            header('HTTP/1.0 403 Forbidden');
            exit('No permission');
        }

        $config   = getModel('module')->getModuleConfig('tablescanner');
        $filename = basename(Context::getRequestVars()->filename ?? '');

        if (!preg_match('/^backup_\d{8}_\d{6}\.sql(\.gz)?$/', $filename)) {
            header('HTTP/1.0 400 Bad Request');
            exit('Invalid filename');
        }

        $filepath = tablescanner::getBackupDir($config) . $filename;
        if (!file_exists($filepath)) {
            header('HTTP/1.0 404 Not Found');
            exit('File not found');
        }

        if (ob_get_level()) ob_end_clean();
        $mime = (substr($filename, -3) === '.gz') ? 'application/gzip' : 'application/octet-stream';
        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filepath));
        header('Cache-Control: no-store');
        header('Pragma: no-cache');
        readfile($filepath);
        exit;
    }

    // ── 백업 설정 저장 ──────────────────────────────────────────
    function procTablescannerAdminSaveBackupConfig()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config) $config = new stdClass();

        $config->backup_auto_enabled  = isset($_POST['backup_auto_enabled']) ? 'Y' : 'N';
        $config->backup_hour          = max(0, min(23, (int)($_POST['backup_hour'] ?? 3)));
        $config->backup_keep_days     = max(1, (int)($_POST['backup_keep_days'] ?? 7));
        $config->backup_path          = trim($_POST['backup_path'] ?? '');
        $config->backup_path2         = trim($_POST['backup_path2'] ?? '');
        $config->backup_method        = in_array($_POST['backup_method'] ?? '', ['auto','php','mysqldump']) ? $_POST['backup_method'] : 'auto';
        $config->backup_email_enabled = isset($_POST['backup_email_enabled']) ? 'Y' : 'N';
        $config->backup_email         = trim($_POST['backup_email'] ?? '');
        $config->backup_email_max_mb  = max(1, min(2048, (int)($_POST['backup_email_max_mb'] ?? 10)));

        getController('module')->insertModuleConfig('tablescanner', $config);

        // Rhymix Queue 비동기 작업 연동
        if (config('queue.enabled')) {
            // 기존 Queue 스케줄 취소
            if (!empty($config->backup_queue_task_srl)) {
                try { \Rhymix\Framework\Queue::cancelScheduledTask((int)$config->backup_queue_task_srl); } catch (\Throwable $e) {}
                $config->backup_queue_task_srl = null;
            }
            // 자동 백업 활성화 시 새 스케줄 등록
            if ($config->backup_auto_enabled === 'Y') {
                try {
                    $interval = sprintf('0 %d * * *', $config->backup_hour);
                    $config->backup_queue_task_srl = \Rhymix\Framework\Queue::addTaskAtInterval($interval, 'tablescanner::runBackupForQueue');
                } catch (\Throwable $e) {}
            }
            getController('module')->insertModuleConfig('tablescanner', $config);
        }

        $this->setMessage(lang('msg_schedule_saved'));
        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminBackup'));
    }

    // ── 크론 키 재발급 ─────────────────────────────────────────
    function procTablescannerAdminRegenerateCronKey()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));

        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config) $config = new stdClass();
        $config->cron_key = bin2hex(random_bytes(16));
        getController('module')->insertModuleConfig('tablescanner', $config);

        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminBackup'));
    }

    // ── CHECK TABLE ────────────────────────────────────────────
    function procTablescannerAdminCheck()
    {
        if (!$this->checkAdmin()) return $this->makeObject(-1, lang('msg_no_permission'));
        @set_time_limit(0);

        $oDB = DB::getInstance();

        $stmt = $oDB->query("select table_name as table_name from information_schema.tables where table_schema = DATABASE() order by table_name", []);
        $all  = [];
        if ($stmt) {
            foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) $all[] = $row->table_name;
        }

        $results = [];
        foreach ($all as $tname) {
            // DB::query()가 내부적으로 이전 statement를 정리하다가(코어 버전에 따라) bool에
            // closeCursor()를 호출해 죽는 환경이 실사용에서 보고됨 — 테이블 하나가 이런 식으로
            // 죽어도 나머지 테이블 점검까지 통째로 중단되지 않도록 테이블별로 감싼다.
            try {
                $chk_stmt = $oDB->query("check table `{$tname}`", []);
                if ($chk_stmt) {
                    foreach ($chk_stmt->fetchAll(PDO::FETCH_OBJ) as $row) $results[] = (array)$row;
                }
            } catch (\Throwable $e) {
                $results[] = ['Table' => $tname, 'Op' => 'check', 'Msg_type' => 'error', 'Msg_text' => $e->getMessage()];
            }
        }

        $cache_file = RX_BASEDIR . 'files/cache/tablescanner_check_result.json';
        file_put_contents($cache_file, json_encode(['ts' => time(), 'results' => $results], JSON_UNESCAPED_UNICODE));

        $this->setRedirectUrl(getNotEncodedUrl('', 'module', 'admin', 'act', 'dispTablescannerAdminCheck'));
    }
}
