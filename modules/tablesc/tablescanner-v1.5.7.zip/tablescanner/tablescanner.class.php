<?php
if(!defined('__XE__')) exit();
class tablescanner extends ModuleObject
{
    public static function cleanupTargets()
    {
        return [
            'session'               => ['label' => '세션 로그',        'date_col' => 'last_update'],
            'counter_log'           => ['label' => '방문 카운터 로그',  'date_col' => 'regdate'],
            'admin_log'             => ['label' => '관리자 활동 로그',  'date_col' => 'regdate'],
            'document_histories'    => ['label' => '문서 수정 이력',    'date_col' => 'regdate'],
            'document_readed_log'   => ['label' => '문서 읽음 로그',    'date_col' => 'regdate'],
            'document_voted_log'    => ['label' => '문서 추천 로그',    'date_col' => 'regdate'],
            'comment_voted_log'     => ['label' => '댓글 추천 로그',    'date_col' => 'regdate'],
            'spamfilter_log'        => ['label' => '스팸 필터 로그',    'date_col' => 'regdate'],
            'document_declared_log' => ['label' => '문서 신고 로그',    'date_col' => 'regdate'],
            'comment_declared_log'  => ['label' => '댓글 신고 로그',    'date_col' => 'regdate'],
        ];
    }

    // ── 백업 디렉토리 경로 ──────────────────────────────────────
    public static function getBackupDir($config = null)
    {
        if ($config && !empty($config->backup_path)) {
            return rtrim(str_replace('\\', '/', $config->backup_path), '/') . '/';
        }
        return RX_BASEDIR . 'files/attach/tablescanner_backup/';
    }

    // ── 백업 실행 (메인) ────────────────────────────────────────
    public static function runBackup($config = null)
    {
        @set_time_limit(0);

        $filename    = 'backup_' . date('Ymd_His') . '.sql';
        $method      = $config->backup_method ?? 'auto';
        $keep_days   = max(1, (int)($config->backup_keep_days ?? 7));

        // 저장 경로 목록 (기본 + 추가)
        $dirs = [self::getBackupDir($config)];
        if (!empty($config->backup_path2)) {
            $dirs[] = rtrim(str_replace('\\', '/', $config->backup_path2), '/') . '/';
        }

        $result_file = null;
        $used_method = '';

        foreach ($dirs as $idx => $backup_dir) {
            if (!is_dir($backup_dir)) {
                mkdir($backup_dir, 0755, true);
                file_put_contents($backup_dir . '.htaccess', "Order deny,allow\nDeny from all\n");
                file_put_contents($backup_dir . 'index.html', '');
            }
            if (!is_writable($backup_dir)) continue;

            $filepath = $backup_dir . $filename;

            if ($idx === 0) {
                // 첫 번째 경로: 실제 덤프 실행
                $tmp_file = null;
                if ($method !== 'php' && self::isExecAvailable() && self::isMysqldumpAvailable()) {
                    $res = self::backupViaMysqldump($filepath, $config);
                    if ($res) { $tmp_file = $res; $used_method = 'mysqldump'; }
                }
                if (!$tmp_file) {
                    $res = self::backupViaPHP($filepath);
                    if ($res) { $tmp_file = $filepath . (function_exists('gzopen') ? '.gz' : ''); $used_method = 'php'; }
                }
                if (!$tmp_file) return ['success' => false, 'error' => '백업 생성 실패 (기본 경로: ' . $backup_dir . ')'];
                $result_file = $tmp_file;
            } else {
                // 추가 경로: 첫 번째 결과 파일을 복사
                $dest = $backup_dir . basename($result_file);
                @copy($result_file, $dest);
            }

            // 오래된 백업 정리
            self::cleanOldBackups($backup_dir, $keep_days);
        }

        if (!$result_file) return ['success' => false, 'error' => '쓰기 가능한 경로가 없습니다'];

        // 이메일 발송
        $email_sent = null;  // null=미설정, true=성공, false=실패, 'size_exceeded'=용량초과
        if (!empty($config->backup_email_enabled) && $config->backup_email_enabled === 'Y' && !empty($config->backup_email)) {
            $max_bytes = (float)($config->backup_email_max_mb ?? 10) * 1024 * 1024;
            if (filesize($result_file) > $max_bytes) {
                $email_sent = 'size_exceeded';
            } else {
                $email_sent = self::sendBackupEmail($result_file, $config->backup_email) ? true : false;
            }
        }

        return [
            'success'    => true,
            'file'       => $result_file,
            'size_kb'    => round(filesize($result_file) / 1024, 1),
            'method'     => $used_method,
            'dirs'       => $dirs,
            'email_sent' => $email_sent,
            'email_to'   => ($email_sent !== null) ? ($config->backup_email ?? '') : '',
        ];
    }

    // ── PHP 기반 덤프 ───────────────────────────────────────────
    private static function backupViaPHP($filepath)
    {
        $oDB     = DB::getInstance();
        $use_gz  = function_exists('gzopen');
        $outfile = $filepath . ($use_gz ? '.gz' : '');

        if ($use_gz) {
            $fp    = gzopen($outfile, 'wb9');
            $write = function($s) use ($fp) { gzwrite($fp, $s); };
            $close = function() use ($fp) { gzclose($fp); };
        } else {
            $fp    = fopen($outfile, 'w');
            $write = function($s) use ($fp) { fwrite($fp, $s); };
            $close = function() use ($fp) { fclose($fp); };
        }
        if (!$fp) return false;

        $write("-- Tablescanner DB Backup\n-- Date: " . date('Y-m-d H:i:s') . "\n-- Host: " . php_uname('n') . "\n\n");
        $write("SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n");

        // 소문자 from: addPrefixes() 우회
        $stmt = $oDB->query("select table_name as table_name from information_schema.tables where table_schema = DATABASE() order by table_name", []);
        if (!$stmt) { $close(); @unlink($outfile); return false; }
        $tables = [];
        foreach ($stmt->fetchAll(PDO::FETCH_OBJ) as $row) $tables[] = $row->table_name;

        foreach ($tables as $table) {
            // CREATE TABLE
            $cs = $oDB->query("show create table `{$table}`", []);
            if ($cs) {
                $rows = $cs->fetchAll(PDO::FETCH_NUM);
                if (!empty($rows)) {
                    $write("--\n-- `{$table}`\n--\nDROP TABLE IF EXISTS `{$table}`;\n" . $rows[0][1] . ";\n\n");
                }
            }
            // 데이터 (500행 단위 배치)
            $offset = 0; $batch = 500; $first = true;
            do {
                $ds   = $oDB->query("select * from `{$table}` limit {$batch} offset {$offset}", []);
                $rows = $ds ? $ds->fetchAll(PDO::FETCH_ASSOC) : [];
                if (empty($rows)) break;
                if ($first) { $first = false; }
                $cols = '`' . implode('`,`', array_keys($rows[0])) . '`';
                foreach ($rows as $row) {
                    $vals = array_map(function($v) {
                        if ($v === null) return 'NULL';
                        return "'" . str_replace(["\\","'","\n","\r","\0"], ["\\\\","\\'","\\n","\\r","\\0"], (string)$v) . "'";
                    }, $row);
                    $write("INSERT INTO `{$table}` ({$cols}) VALUES (" . implode(',', $vals) . ");\n");
                }
                $offset += $batch;
            } while (count($rows ?? []) === $batch);
            $write("\n");
        }
        $write("SET FOREIGN_KEY_CHECKS=1;\n");
        $close();
        return true;
    }

    // ── mysqldump 기반 백업 ─────────────────────────────────────
    private static function backupViaMysqldump($filepath, $config)
    {
        $db   = \Rhymix\Framework\Config::get('db.master');
        $host = $db['host']     ?? 'localhost';
        $port = (int)($db['port'] ?? 3306);
        $user = $db['user']     ?? '';
        $pass = $db['password'] ?? '';
        $name = $db['database'] ?? '';

        // 비밀번호를 임시 설정 파일로 처리 (커맨드라인 노출 방지)
        $tmp = tempnam(sys_get_temp_dir(), 'ts_bk_');
        file_put_contents($tmp, "[client]\npassword=" . $pass . "\n");
        chmod($tmp, 0600);

        $has_gzip = false;
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            exec('where gzip 2>nul', $out, $ret);
        } else {
            exec('which gzip 2>/dev/null', $out, $ret);
        }
        if ($ret === 0 || !empty($out)) $has_gzip = true;

        // --single-transaction: InnoDB 테이블 잠금 없이 일관된 스냅샷 백업 (서비스 중단 방지)
        // --skip-lock-tables: 명시적 LOCK TABLES 생략 (single-transaction과 함께 사용)
        $dump_opts = '--single-transaction --skip-lock-tables --routines --triggers';

        if ($has_gzip) {
            $outfile = $filepath . '.gz';
            $cmd = sprintf('mysqldump --defaults-extra-file=%s -h %s -P %d -u %s %s %s | gzip > %s 2>&1',
                escapeshellarg($tmp), escapeshellarg($host), $port,
                escapeshellarg($user), $dump_opts, escapeshellarg($name), escapeshellarg($outfile));
        } else {
            $outfile = $filepath;
            $cmd = sprintf('mysqldump --defaults-extra-file=%s -h %s -P %d -u %s %s %s > %s 2>&1',
                escapeshellarg($tmp), escapeshellarg($host), $port,
                escapeshellarg($user), $dump_opts, escapeshellarg($name), escapeshellarg($outfile));
        }

        exec($cmd, $output, $return_code);
        @unlink($tmp);

        if ($return_code !== 0 || !file_exists($outfile) || filesize($outfile) < 100) {
            @unlink($outfile);
            return false;
        }
        return $outfile;
    }

    // ── 오래된 백업 삭제 ────────────────────────────────────────
    public static function cleanOldBackups($backup_dir, $keep_days)
    {
        $threshold = time() - $keep_days * 86400;
        foreach (glob($backup_dir . 'backup_*.sql*') ?: [] as $file) {
            if (filemtime($file) < $threshold) @unlink($file);
        }
    }

    // ── Queue 핸들러 (Rhymix 비동기 작업 시스템용) ─────────────
    public static function runBackupForQueue($args = null, $options = null)
    {
        $config = getModel('module')->getModuleConfig('tablescanner');
        if (!$config || empty($config->backup_auto_enabled) || $config->backup_auto_enabled !== 'Y') {
            return;
        }

        $result = self::runBackup($config);

        if (!empty($result['success'])) {
            $config->backup_last_backup   = time();
            $es           = $result['email_sent'] ?? null;
            $email_status = ($es === true) ? 'sent' : (($es === false) ? 'failed' : (($es === 'size_exceeded') ? 'size_exceeded' : 'disabled'));
            $config->backup_last_email_status = $email_status;
            $config->backup_last_email_time   = time();
            $email_log = is_array($config->backup_email_log ?? null) ? $config->backup_email_log : (array)($config->backup_email_log ?? []);
            $email_log[basename($result['file'])] = $email_status;
            if (count($email_log ?? []) > 50) $email_log = array_slice($email_log, -50, 50, true);
            $config->backup_email_log = (object)$email_log;
            $type_log = is_array($config->backup_type_log ?? null) ? $config->backup_type_log : (array)($config->backup_type_log ?? []);
            $type_log[basename($result['file'])] = 'auto';
            if (count($type_log ?? []) > 50) $type_log = array_slice($type_log, -50, 50, true);
            $config->backup_type_log = (object)$type_log;
            getController('module')->insertModuleConfig('tablescanner', $config);
        }
    }

    // ── 이메일 발송 ─────────────────────────────────────────────
    private static function sendBackupEmail($filepath, $email)
    {
        try {
            $site_title  = \Rhymix\Framework\Config::get('site_title') ?: 'Site';
            $from_email  = config('mail.default_from') ?: $email;
            $from_name   = config('mail.default_name') ?: $site_title;

            $mail = new \Rhymix\Framework\Mail();
            $mail->setFrom($from_email, $from_name);
            $mail->setSubject('[' . $site_title . '] DB 백업 — ' . date('Y-m-d'));
            $mail->setBody(
                'DB 자동 백업 파일이 첨부됩니다.' . "\n\n" .
                '일시: ' . date('Y-m-d H:i:s') . "\n" .
                '파일: ' . basename($filepath) . "\n" .
                '크기: ' . number_format(filesize($filepath) / 1024, 1) . ' KB',
                'text/plain'
            );
            $mail->addTo($email);
            $mail->attach($filepath, basename($filepath));
            $mail->send(true);  // 동기 전송 (Queue 우회)
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    // ── 유틸리티 ────────────────────────────────────────────────
    public static function isExecAvailable()
    {
        if (!function_exists('exec')) return false;
        $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
        return !in_array('exec', $disabled ?? []);
    }

    public static function isMysqldumpAvailable()
    {
        if (!self::isExecAvailable()) return false;
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            exec('where mysqldump 2>nul', $out, $ret);
        } else {
            exec('which mysqldump 2>/dev/null', $out, $ret);
        }
        return $ret === 0 || !empty($out);
    }

    // ────────────────────────────────────────────────────────────

    private $actions = [
        ['tablescanner', 'view',       'dispTablescannerAdminScan'],
        ['tablescanner', 'view',       'dispTablescannerAdminDashboard'],
        ['tablescanner', 'view',       'dispTablescannerAdminOptimize'],
        ['tablescanner', 'view',       'dispTablescannerAdminCleanup'],
        ['tablescanner', 'view',       'dispTablescannerAdminCheck'],
        ['tablescanner', 'view',       'dispTablescannerAdminBackup'],
        ['tablescanner', 'controller', 'procTablescannerAdminOptimize'],
        ['tablescanner', 'controller', 'procTablescannerAdminCleanup'],
        ['tablescanner', 'controller', 'procTablescannerAdminCheck'],
        ['tablescanner', 'controller', 'procTablescannerAdminDropTable'],
        ['tablescanner', 'controller', 'procTablescannerAdminSaveSchedule'],
        ['tablescanner', 'controller', 'procTablescannerAdminRunBackup'],
        ['tablescanner', 'controller', 'procTablescannerAdminDeleteBackup'],
        ['tablescanner', 'controller', 'procTablescannerAdminDownloadBackup'],
        ['tablescanner', 'controller', 'procTablescannerAdminSaveBackupConfig'],
        ['tablescanner', 'controller', 'procTablescannerCronRun'],
        ['tablescanner', 'controller', 'procTablescannerAdminRegenerateCronKey'],
    ];

    function moduleInstall()
    {
        $oModuleController = getController('module');
        foreach ($this->actions as $a) {
            $oModuleController->insertActionForward($a[0], $a[1], $a[2]);
        }
        $oModuleController->insertTrigger('before_module_proc', 'tablescanner', 'controller', 'triggerAutoCleanup', 'before');
        $oModuleController->insertTrigger('after_module_proc',  'tablescanner', 'controller', 'triggerAutoBackup',  'after');
    }

    function checkUpdate()
    {
        $oModuleModel = getModel('module');
        foreach ($this->actions as $a) {
            if (!$oModuleModel->getActionForward($a[2])) return true;
        }
        return false;
    }

    function moduleUpdate()
    {
        $oModuleController = getController('module');
        $oModuleModel      = getModel('module');
        foreach ($this->actions as $a) {
            if (!$oModuleModel->getActionForward($a[2])) {
                $oModuleController->insertActionForward($a[0], $a[1], $a[2]);
            }
        }
        $oModuleController->deleteTrigger('before_module_proc', 'tablescanner', 'controller', 'triggerAutoCleanup', 'before');
        $oModuleController->insertTrigger('before_module_proc',  'tablescanner', 'controller', 'triggerAutoCleanup', 'before');
        $oModuleController->deleteTrigger('after_module_proc',  'tablescanner', 'controller', 'triggerAutoBackup',  'after');
        $oModuleController->insertTrigger('after_module_proc',   'tablescanner', 'controller', 'triggerAutoBackup',  'after');
    }
}
