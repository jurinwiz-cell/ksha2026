<?php
if(!defined('__XE__')) exit();
class TablescannerAdminView extends tablescanner
{
    function init()
    {
        Context::loadFile(['modules/tablescanner/tpl/admin/css/style.css', 'all']);
        Context::set('db_prefix', DB::getInstance()->prefix);
    }

    function dispTablescannerAdminScan()
    {
        $oModel = getModel('tablescanner');
        Context::set('scan', $oModel->scanTables());
        Context::set('current_tab', 'scan');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('scan');
    }

    function dispTablescannerAdminDashboard()
    {
        $oModel = getModel('tablescanner');
        Context::set('dash', $oModel->getDashboardData());
        Context::set('current_tab', 'dashboard');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('dashboard');
    }

    function dispTablescannerAdminOptimize()
    {
        $oModel = getModel('tablescanner');
        Context::set('optimize_data', $oModel->getOptimizeData());
        Context::set('current_tab', 'optimize');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('optimize');
    }

    function dispTablescannerAdminCleanup()
    {
        $oModel  = getModel('tablescanner');
        $sconfig = getModel('module')->getModuleConfig('tablescanner');
        Context::set('cleanup_data', $oModel->getCleanupData());
        Context::set('schedule', $sconfig ?: new stdClass());
        Context::set('all_targets', tablescanner::cleanupTargets());
        Context::set('current_tab', 'cleanup');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('cleanup');
    }

    function dispTablescannerAdminBackup()
    {
        $oModel  = getModel('tablescanner');
        $sconfig = getModel('module')->getModuleConfig('tablescanner');
        $config  = $sconfig ?: new stdClass();

        $backup_dir    = tablescanner::getBackupDir($config);
        $dir_writable  = is_dir($backup_dir) ? is_writable($backup_dir) : @is_writable(dirname(rtrim($backup_dir, '/')));
        $dir2_writable = false;
        if (!empty($config->backup_path2)) {
            $d2 = rtrim(str_replace('\\', '/', $config->backup_path2), '/') . '/';
            $dir2_writable = is_dir($d2) ? is_writable($d2) : @is_writable(dirname(rtrim($d2, '/')));
        }
        $exec_ok      = tablescanner::isExecAvailable();
        $mysqldump_ok = tablescanner::isMysqldumpAvailable();
        $gzip_ok      = function_exists('gzopen');
        // 크론 키 자동 생성 (최초 1회)
        if (empty($config->cron_key)) {
            $config->cron_key = bin2hex(random_bytes(16));
            getController('module')->insertModuleConfig('tablescanner', $config);
        }
        $cron_url = getFullUrl('', 'module', 'tablescanner', 'act', 'procTablescannerCronRun', 'cron_key', $config->cron_key);

        // 백업 경로 웹 접근 위험 검사
        $web_root     = rtrim(str_replace('\\', '/', RX_BASEDIR), '/');
        $check_dir    = rtrim(str_replace('\\', '/', $backup_dir), '/');
        $dir_in_web   = (strpos($check_dir, $web_root) === 0);  // 웹 루트 하위 여부
        $dir_in_attach = (strpos($check_dir, $web_root . '/files/attach') === 0);

        $queue_enabled     = (bool)config('queue.enabled');
        $queue_scheduled   = $queue_enabled && !empty($config->backup_queue_task_srl);
        $last_backup       = !empty($config->backup_last_backup) ? date('Y-m-d H:i:s', (int)$config->backup_last_backup) : '없음';
        $last_email_status = $config->backup_last_email_status ?? null;
        $last_email_time   = !empty($config->backup_last_email_time) ? date('Y-m-d H:i:s', (int)$config->backup_last_email_time) : null;

        Context::set('backup_config',      $config);
        Context::set('backup_dir',       $backup_dir);
        Context::set('dir_writable',     $dir_writable);
        Context::set('dir2_writable',    $dir2_writable);
        Context::set('exec_ok',          $exec_ok);
        Context::set('mysqldump_ok',     $mysqldump_ok);
        Context::set('gzip_ok',          $gzip_ok);
        Context::set('last_backup',        $last_backup);
        Context::set('last_email_status',  $last_email_status);
        Context::set('last_email_time',    $last_email_time);
        Context::set('cron_url',           $cron_url);
        Context::set('cron_key',           $config->cron_key);
        Context::set('dir_in_web',         $dir_in_web);
        Context::set('dir_in_attach',      $dir_in_attach);
        Context::set('queue_enabled',      $queue_enabled);
        Context::set('queue_scheduled',    $queue_scheduled);
        Context::set('backup_list',      $oModel->getBackupList($config));
        Context::set('current_tab',      'backup');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('backup');
    }

    function dispTablescannerAdminCheck()
    {
        $oModel = getModel('tablescanner');
        $data   = $oModel->getCheckData();

        $cache_file = RX_BASEDIR . 'files/cache/tablescanner_check_result.json';
        if (file_exists($cache_file)) {
            $cached = json_decode(file_get_contents($cache_file), true);
            if (is_array($cached) && isset($cached['ts']) && time() - $cached['ts'] < 3600) {
                $data['results'] = $cached['results'];
            }
            @unlink($cache_file);
        }

        Context::set('check_data', $data);
        Context::set('current_tab', 'check');
        $this->setTemplatePath($this->module_path . 'tpl/admin');
        $this->setTemplateFile('check');
    }
}
