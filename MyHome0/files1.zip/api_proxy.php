<?php
// ODCloud API 프록시 — CORS 우회용
// 웹루트(index.html 있는 폴더)에 올려두면 됩니다.

$API_KEY = '39b51115717872f9630f0d8f64456e9eec660a40b94c327b847b741a7647656f';
$API_BASE = 'https://api.odcloud.kr/api/15084926/v1/uddi:bc7f22b9-b711-4a07-9de3-f0668c1d64c6';

$page    = isset($_GET['page'])    ? intval($_GET['page'])    : 1;
$perPage = isset($_GET['perPage']) ? intval($_GET['perPage']) : 10;

$query = "page={$page}&perPage={$perPage}&serviceKey={$API_KEY}";

// cond[필드::LIKE]=값 파라미터 — 키 그대로 전달
foreach ($_GET as $key => $val) {
    if (strpos($key, 'cond[') === 0) {
        $query .= '&' . urlencode($key) . '=' . urlencode($val);
    }
}

$url = $API_BASE . '?' . $query;

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_HTTPHEADER     => ['Accept: application/json'],
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error    = curl_error($ch);
curl_close($ch);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

if ($error) {
    http_response_code(502);
    echo json_encode(['error' => 'ODCloud 연결 실패: ' . $error]);
} else {
    http_response_code($httpCode);
    echo $response;
}
