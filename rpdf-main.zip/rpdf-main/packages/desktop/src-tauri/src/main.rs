#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    rpdf_desktop_lib::run()
}
