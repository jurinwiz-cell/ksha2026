<?php

class Extravar_uploadModel extends Extravar_upload
{
	public function getImageFiles($upload_target_srl, $set_cover_first = false)
	{
		if(!$upload_target_srl)return false;
		
		$args = new stdClass;
		$args->upload_target_srl = $upload_target_srl;
		$args->order_type = 'asc';
		$args->isvalid = 'Y';
		$output = executeQueryArray('extravar_upload.getFilesListByUploadTargetSrl', $args);
		if(!$output->toBool()) return false;
		$temp_output = Array();
		foreach($output->data as $no => $data){
			$match = preg_match('/\.(jpg|jpeg|gif|png)$/', strtolower($data->uploaded_filename), $output_array);
			if($match !== 0)$temp_output[] = $data;
		}
		if(count($temp_output) > 0){
			if($set_cover_first){
				$temp_file = array();
				foreach($temp_output as $no => $data){
					if($data->cover_extra == 'Y'){
						array_unshift($temp_file, $data);
					}else{
						$temp_file[] = $data;
					}
				}
				return $temp_file;
			}else{
				return $temp_output;
			}
		}else{
			return Null;
		}
	}
	
	public function getFiles($upload_target_srl)
	{
		if(!$upload_target_srl)return false;
		
		$args = new stdClass;
		$args->upload_target_srl = $upload_target_srl;
		$args->order_type = 'asc';
		$args->isvalid = 'Y';
		$output = executeQueryArray('extravar_upload.getFilesListByUploadTargetSrl', $args);
		if(!$output->toBool()) return false;
		return $output->data;
	}

	public function getCoverFile($upload_target_srl)
	{
		if(!$upload_target_srl)return false;
		
		$args = new stdClass;
		$args->upload_target_srl = $upload_target_srl;
		$output = executeQuery('extravar_upload.getCoverByUploadTargetSrl', $args);
		if($output->data){
			$file_info = $output->data;
		}else{
			$files = $this->getImageFiles($upload_target_srl);
			if($files[0])$file_info = $files[0];
		}
		if($file_info){
			$reg_info = $this->getRegInfo($file_info->module_srl, $file_info->eid);
			$file_info->cover_size_width = $reg_info->cover_size_width;
			$file_info->cover_size_height = $reg_info->cover_size_height;
			$file_info->cover_extra_url = $file_info->uploaded_filename;
			return $file_info;
		}
	}

	function getRegInfo($module_srl, $eid)
	{
		if(!$module_srl)return false;
		if(!$eid)return false;
		$args = new stdClass;
		$args->target_module_srl = $module_srl;
		$args->eid = $eid;
		$output = executeQuery('extravar_upload.getReginfo', $args);
		return $output->data;
	}
}
