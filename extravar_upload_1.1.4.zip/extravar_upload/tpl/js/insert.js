function SelectExtraKey(){
	jQuery('select[name=extra_idx]').html('');
	var module_srl = jQuery('select[name=module_srl]').val();
	var params = {
	'module_srl' : module_srl,
	};
	exec_json('extravar_upload.procExtravar_uploadAdminGetExtraKeys',params,function(data) {
		var message = data.message;
		if(message != 'success') {
			alert(message);
			return false;
		}else{
			jQuery.each(data.file_srl, function(idx, item){
				jQuery('select[name=extra_idx]').append('<option default_value="'+item.default+'" is_required_value="'+item.is_required+'"type_value="'+item.type+'" value="'+item.eid+'">'+item.name+' ('+item.eid+')</option>');
			});
		}
	});
};

function AddExtraKey(){
	var idx = jQuery('select#extra_idx option:selected').val();
	if(!idx){
		alert('확장변수가 선택 되지 않았습니다.');
		return false;
	}
	var def = jQuery('select#extra_idx option:selected').attr('default_value');
	if(!/^%.+?%$/i.test(def)) {
		alert('기본값 형식이 잘못 되었습니다.!');
		return false;	
	}
	//var required = jQuery('select#extra_idx option:selected').attr('is_required_value');
	//if(required != 'Y'){
	//	alert('필수항목이 Y가 아닙니다!');
	//	return false;	
	//}
	var sel = jQuery('select#extra_idx option:selected').attr('type_value');
	if(sel != 'select'){
		alert('확장변수가 Select 타입이 아닙니다!');
		return false;	
	}
	var txt = jQuery('select#extra_idx option:selected').text();
	var m_srl = jQuery('select[name=module_srl] option:selected').val();
	var board_name = jQuery('select[name=module_srl] option:selected').text();
	var svalue = m_srl+','+idx;
	
	var target_list = new Array();
	
	jQuery('input[id=target_list]').each(function(i,item){
		target_list.push(jQuery(this).val());
	});
	if(target_list.indexOf(svalue) != -1){
		alert('이미 선택된 대상입니다.');
		return false;
	};
	jQuery('div[id=target_list]').prepend('<input type="hidden" name="target_list[]" id="target_list" value="'+svalue+'" />');
	jQuery('select#target_list').append('<option value="'+svalue+'">'+board_name+' > '+txt+'</option>');
};

function SelectRemove(){
	var remove_v = jQuery('select#target_list option:selected').val();
	jQuery('input[id=target_list][value="'+remove_v+'"]').remove();
	jQuery('select#target_list option:selected').remove();
}